print("dir1")
