from .result import Result, Ok, Err, UnwrapError, OkErr
__all__ = ['Result', 'Ok', 'Err', 'UnwrapError', 'OkErr']
